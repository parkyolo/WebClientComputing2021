import React from "react";
import PropTypes from "prop-types";
import "./Movie.css";

function Movie({id, year, title, poster, rating, director, actor}) {
  return (
    <div className="movie">
      <img className="movie_poster" src={poster} alt={title} titlt={title}></img>
      <div className="inner">
        <div className="movie__data">
          <h3 className="movie__title">{
              title.replace(/<b>/gi,"").replace(/<\/b>/gi,"")
            }</h3>
          <p className="movie__rating">
            <span className="tr">평점</span>&emsp;&emsp;{rating}/10
          </p>
          <p className="movie__year">
            <span className="tr">개봉일</span>&emsp;{year}
          </p>
        <p className="movie__director">
          <span className="tr">감독</span>&emsp;&emsp;{director}
        </p>
        <p className="movie__actor">
          <span className="tr">배우</span>&emsp;&emsp;{actor}
        </p>
        </div>
      </div>
    </div>
  )
};

Movie.propTypes = {
  id: PropTypes.string.isRequired,
  year: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  poster: PropTypes.string.isRequired,
  rating: PropTypes.string.isRequired,
  director: PropTypes.string.isRequired,
  actor: PropTypes.string.isRequired

};

export default Movie;
