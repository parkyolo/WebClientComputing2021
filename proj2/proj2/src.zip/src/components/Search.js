import React from "react";
import Movie from './Movie';
import "./Search.css";
import {naverMoviesApi} from '../api';

class proj2 extends React.Component {
    state = {
      isLoading: false,
      movies: [],
      value: "",
      name: "영화 검색",
      movie: {},
      showMovie: false
    };
  
    getSearchMovie = async () => {
      console.log('search Movie');
      const search = this.state.value;
  
      try {
        if (search === "") {
          this.setState({movies: [], isLoading: false})
        } else {
          this.setState({movies: [], isLoading: true})
          const {data: {
              items
            }} = await naverMoviesApi.search(search);
          //alert("(Loading 메시지 확인중...)");
          this.setState({movies: items, isLoading: false});
          console.log(this.state.movies);
        }
      } catch (error) {
        console.log(error);
      }
    };
  
    componentDidMount() {
      this.getSearchMovie();
    };
  
    handleChange = (e : any) => {
      this.setState({value: e.target.value});
    };
  
    handleSubmit = (e : any) => {
      e.preventDefault();
      this.getSearchMovie();
    };

    handleMovie = (movie, e) => {
      e.preventDefault();
      this.setState({movie: movie});
      this.setState({showMovie: true});
    }
  
    render() {
      const {movies, isLoading, name, movie} = this.state;
  
      return (<section className="container">
        {
          isLoading
            ? (<div className="loader">
              <span className="loader__text">({this.state.name}) Loading... {this.state.value}</span>
            </div>)
            : (<form onSubmit={this.handleSubmit}>
              <div className="inner_container">
                <div className="input_div">
                  <h1 className="input_title">영화 검색 서비스</h1>
                  <div style={{display: "flex"}}>
                    <input className="input_search" type="text" value={this.state.value} onChange={this.handleChange} placeholder="영화 이름을 입력하세요"/>
                    <div className="plus_box">+</div>
                  </div>
                </div>
                <div className="movies">
                  {movies.map((movie,i) => (
                    <button className="movie_btn" onClick={this.handleMovie.bind(this, movie)}>{i+1}</button>
                    )
                  )}
                  {this.state.showMovie ? <Movie key={movie.link} id={movie.link} year={movie.pubDate} title={movie.title} poster={movie.image} rating={movie.userRating} director={movie.director} actor={movie.actor}/>: null}
                </div>
              </div>
            </form>)
        }
      </section>);
    }
  }
  
  export default proj2;